%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-19T08:56:06+09:00*%
%TF.ProjectId,carrier,63617272-6965-4722-9e6b-696361645f70,0.1 (concept)*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-19 08:56:06*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,H4*%
X207500000Y-200000000D03*
%TD*%
%TO.C,H3*%
X207500000Y-100000000D03*
%TD*%
%TO.C,H1*%
X92500000Y-100000000D03*
%TD*%
%TO.C,H2*%
X92500000Y-200000000D03*
%TD*%
M02*
